# TÀI LIỆU CẤU TRÚC CƠ SỞ DỮ LIỆU
**Dự án:** Phần mềm Quản lý Phòng khám Da liễu
**Hệ quản trị:** SQL Server

## 1. Sơ đồ các Bảng (Tables)
Hệ thống được thiết kế chuẩn hóa, bao gồm 16 bảng phân chia theo 4 nhóm nghiệp vụ chính:

### Nhóm Danh mục & Con người
* **VaiTro**: `MaVaiTro` (PK), `TenVaiTro`.
* **CaLamViec**: `MaCa` (PK), `TenCa`, `GioBatDau`, `GioKetThuc`.
* **DichVu**: `MaDichVu` (PK), `TenDichVu`, `DonGia`.
* **NhaCungCap**: `MaNhaCungCap` (PK), `TenNhaCungCap`, `SoDienThoaiLienHe`, `DiaChi`.
* **NhanVien**: `MaNhanVien` (PK), `HoTen`, `SoDienThoai`, `Email`, `TenDangNhap`, `MatKhau`, `MaVaiTro` (FK).
* **BenhNhan**: `MaBenhNhan` (PK), `HoTen`, `NgaySinh`, `GioiTinh`, `SoDienThoai`, `TienSuBenhLy`.

### Nhóm Kho bãi (Dược - Mỹ phẩm)
* **Thuoc**: `MaThuoc` (PK), `TenThuoc`, `DonViTinh`, `DonGia`, `SoLuongTon`.
* **PhieuNhapKho**: `MaPhieuNhap` (PK), `MaNhaCungCap` (FK), `MaNhanVien` (FK), `NgayNhap`, `TongGiaTri`.
* **ChiTietNhapKho**: `MaPhieuNhap` (PK, FK), `MaThuoc` (PK, FK), `SoLuong`, `SoLuongConLai` (Phục vụ FIFO), `GiaNhap`, `HanSuDung`.

### Nhóm Nghiệp vụ Khám chữa bệnh
* **PhanCongCa**: `MaPhanCong` (PK), `MaNhanVien` (FK), `MaCa` (FK), `NgayLamViec`, `TrangThaiDiemDanh`.
* **LichHen**: `MaLichHen` (PK), `MaBenhNhan` (FK), `MaBacSi` (FK), `ThoiGianHen`, `TrangThai`.
* **PhieuKham**: `MaPhieuKham` (PK), `MaBenhNhan` (FK), `MaBacSi` (FK), `NgayKham`, `TrieuChung`, `ChanDoan`, `NgayTaiKham`.
* **ChiTietDichVu**: `MaPhieuKham` (PK, FK), `MaDichVu` (PK, FK), `SoLuong`, `ThanhTien`.
* **ChiTietDonThuoc**: `MaPhieuKham` (PK, FK), `MaThuoc` (PK, FK), `SoLuong`, `LieuDung`.

### Nhóm Tài chính
* **ChiPhiHoatDong**: `MaChiPhi` (PK), `LoaiChiPhi`, `SoTien`, `NgayChi`, `GhiChu`, `NguoiTao` (FK).
* **HoaDon**: `MaHoaDon` (PK), `MaPhieuKham` (FK - UNIQUE), `TongTien`, `GiamGia`, `TienKhachTra`, `PhuongThucThanhToan`, `NgayThanhToan`, `TrangThai`.

---

## 2. Các Ràng buộc toàn vẹn (Constraints)
* **PK / FK**: Đầy đủ các khóa chính và khóa ngoại để liên kết các bảng.
* **CHECK Constraints**:
    * Thời gian ca làm việc: `GioKetThuc > GioBatDau`.
    * Tài chính: `DonGia >= 0`, `SoTien > 0`.
    * Tồn kho: `SoLuongTon >= 0` (Chống bán âm).
    * Logic khám bệnh: `NgayTaiKham >= NgayKham`, Trạng thái lịch hẹn thuộc (0, 1, 2).
* **UNIQUE**: Số điện thoại Bệnh nhân/Nhân viên không được trùng, `TenDangNhap` là duy nhất. 1 Phiếu khám chỉ có 1 Hóa đơn duy nhất.

---

## 3. Các Luồng xử lý Tự động (Triggers & Views)
* **Views**: `VW_HoSoBenhAn` (Xem chi tiết hồ sơ bệnh nhân), `VW_BaoCaoDoanhThu` (Báo cáo tài chính).
* **Trigger**: `TRG_NhapKho_CapNhatTon` (Tự động cộng `SoLuongTon` vào bảng Thuốc khi có phiếu nhập kho mới).

---

## 4. Các Thuật toán cốt lõi (Stored Procedures)
* **`SP_DatLichHenMoi`**: Chống trùng lịch hẹn. Tự động chặn nếu bác sĩ đã có khách trong khung giờ ±29 phút.
* **`SP_KeDonThuoc_FIFO`**: Thuật toán bán thuốc thông minh. Tự động vét kho ưu tiên lô thuốc Cận Date (Hết hạn trước - Xuất trước) bằng con trỏ (CURSOR).
* **`SP_TiepNhanBenhNhan_AnToan`**: Giao dịch ACID. Gói gọn 3 thao tác (Tạo Phiếu Khám -> Thêm Dịch vụ -> Khởi tạo Hóa đơn) vào 1 Transaction. Rollback 100% nếu có sự cố.

---

## 5. Lưu vết Bảo mật (Audit Trail / Temporal Tables)
Hệ thống sử dụng tính năng **System-Versioned Temporal Tables** của SQL Server để tự động lưu lịch sử chỉnh sửa, xóa dữ liệu đối với 2 bảng nhạy cảm:
* `PhieuKham` -> Bảng lịch sử: `PhieuKham_LichSu` (Chống sửa lén chẩn đoán/hồ sơ bệnh án).
* `HoaDon` -> Bảng lịch sử: `HoaDon_LichSu` (Chống thủ quỹ/kế toán gian lận tài chính).



///////////////////////////////////////////////////////////////////////////////////////////////////
# TÀI LIỆU KIẾN TRÚC PHẦN MỀM
**Dự án:** Phần mềm Quản lý Phòng khám Da liễu
**Công nghệ:** C# Windows Forms App (.NET Framework 4.8)
**Kiến trúc:** Mô hình 3 Lớp (3-Tier Architecture) + DTO + Singleton Pattern

## 1. Sơ đồ Kiến trúc Thư mục (Solution Explorer)
```text
QuanLyPhongKhamDaLieu/
│
├── App.config               # File cấu hình chứa Connection String (System.Configuration)
│
├── DTO/                     # DATA TRANSFER OBJECT (Lớp Đối tượng)
│   └── BenhNhanDTO.cs       # Ánh xạ các cột của bảng BenhNhan thành các Thuộc tính (Properties)
│
├── DAL/                     # DATA ACCESS LAYER (Lớp Truy xuất dữ liệu)
│   ├── DataProvider.cs      # "Trái tim" của hệ thống, quản lý SqlConnection và các hàm Execute
│   └── BenhNhanDAL.cs       # Chứa các câu lệnh SQL (SELECT, INSERT...) thao tác với bảng BenhNhan
│
├── BLL/                     # BUSINESS LOGIC LAYER (Lớp Xử lý nghiệp vụ)
│   └── BenhNhanBLL.cs       # Kiểm tra logic (Rỗng, sai định dạng...) trước khi gọi xuống DAL
│
└── GUI/                     # GRAPHICAL USER INTERFACE (Lớp Giao diện WinForms)
    └── Form1.cs (frmMain)   # Màn hình giao diện, chỉ chứa các Event kéo thả (Button Click, Load...)