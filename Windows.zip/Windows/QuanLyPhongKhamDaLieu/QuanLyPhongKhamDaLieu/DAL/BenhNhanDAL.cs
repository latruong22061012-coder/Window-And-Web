﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace QuanLyPhongKhamDaLieu.DAL
{
    public class BenhNhanDAL
    {
        // Thiết kế Singleton
        private static BenhNhanDAL instance;
        public static BenhNhanDAL Instance
        {
            get { if (instance == null) instance = new BenhNhanDAL(); return BenhNhanDAL.instance; }
            private set { BenhNhanDAL.instance = value; }
        }
        private BenhNhanDAL() { }

        // Hàm nhờ DataProvider lấy dữ liệu
        public DataTable LayDanhSachBenhNhan()
        {
            string query = "SELECT MaBenhNhan AS [Mã BN], HoTen AS [Họ Tên], NgaySinh AS [Ngày Sinh], SoDienThoai AS [SĐT], TienSuBenhLy AS [Tiền Sử Bệnh] FROM BenhNhan";

            // Đây chính là lúc DataProvider thể hiện sức mạnh!
            return DataProvider.Instance.ExecuteQuery(query);
        }
    }
}
