﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace QuanLyPhongKhamDaLieu_New.DAL
{
    public class DataProvider
    {
        // 1. THIẾT KẾ SINGLETON PATTERN
        // Giúp các Form khác gọi DataProvider.Instance mà không cần khởi tạo lại (new DataProvider())
        private static DataProvider instance;
        public static DataProvider Instance
        {
            get { if (instance == null) instance = new DataProvider(); return DataProvider.instance; }
            private set { DataProvider.instance = value; }
        }

        private DataProvider() { }

        // 2. ĐỌC CHUỖI KẾT NỐI TỪ APP.CONFIG
        private string connectionString = ConfigurationManager.ConnectionStrings["QL_PHONGKHAMDALIEU_New"].ConnectionString;

        // 3. VŨ KHÍ 1: EXECUTE QUERY (Chuyên dùng cho lệnh SELECT)
        // Trả về một bảng dữ liệu (DataTable) để bạn đổ thẳng lên DataGridView
        public DataTable ExecuteQuery(string query, object[] parameter = null)
        {
            DataTable data = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);

                if (parameter != null)
                {
                    string[] listPara = query.Split(' ');
                    int i = 0;
                    foreach (string item in listPara)
                    {
                        if (item.Contains('@'))
                        {
                            command.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        // 4. VŨ KHÍ 2: EXECUTE NON QUERY (Chuyên dùng cho INSERT, UPDATE, DELETE)
        // Trả về số nguyên (int) là số dòng dữ liệu thực tế đã bị ảnh hưởng thành công
        public int ExecuteNonQuery(string query, object[] parameter = null)
        {
            int data = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);

                if (parameter != null)
                {
                    string[] listPara = query.Split(' ');
                    int i = 0;
                    foreach (string item in listPara)
                    {
                        if (item.Contains('@'))
                        {
                            command.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }

                data = command.ExecuteNonQuery();
                connection.Close();
            }
            return data;
        }

        // 5. VŨ KHÍ 3: EXECUTE SCALAR (Chuyên dùng cho đếm COUNT(*), tính tổng SUM)
        // Trả về một ô dữ liệu duy nhất (object)
        public object ExecuteScalar(string query, object[] parameter = null)
        {
            object data = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);

                if (parameter != null)
                {
                    string[] listPara = query.Split(' ');
                    int i = 0;
                    foreach (string item in listPara)
                    {
                        if (item.Contains('@'))
                        {
                            command.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }

                data = command.ExecuteScalar();
                connection.Close();
            }
            return data;
        }
    }
}