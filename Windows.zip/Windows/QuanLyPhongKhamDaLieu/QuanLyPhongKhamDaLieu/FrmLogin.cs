﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyPhongKhamDaLieu_New
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Đọc chuỗi kết nối có tên "PhongKhamDB" từ file App.config
                string connectionString = ConfigurationManager.ConnectionStrings["QL_PHONGKHAMDALIEU_New"].ConnectionString;

                // 2. Thử mở kết nối đến SQL Server
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open(); // Nếu sai tên máy chủ hoặc sai tên CSDL, phần mềm sẽ văng lỗi ngay dòng này

                    // 3. Nếu lọt qua được dòng Open() mà không lỗi, nghĩa là đã kết nối thành công!
                    MessageBox.Show("Tuyệt vời! Kết nối Cơ sở dữ liệu THÀNH CÔNG! 🎉",
                                    "Thông báo",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);

                    connection.Close(); // Test xong thì đóng lại cho gọn gàng
                }
            }
            catch (Exception ex)
            {
                // Nếu kết nối thất bại, hiện hộp thoại báo lỗi chi tiết
                MessageBox.Show("Kết nối THẤT BẠI. Vui lòng kiểm tra lại App.config!\n\nLỗi chi tiết: " + ex.Message,
                                "Lỗi kết nối",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }
        }
    }
}
