﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using QuanLyPhongKhamDaLieu.DAL; //Gọi thư mục để sử dụng

namespace QuanLyPhongKhamDaLieu.BLL
{
    public class BenhNhanBLL
    {
        private static BenhNhanBLL instance;
        public static BenhNhanBLL Instance
        {
            get { if (instance == null) instance = new BenhNhanBLL(); return BenhNhanBLL.instance; }
            private set { BenhNhanBLL.instance = value; }
        }
        private BenhNhanBLL() { }

        // Hàm cung cấp dữ liệu cho Form
        public DataTable LayDanhSachBenhNhan()
        {
            return BenhNhanDAL.Instance.LayDanhSachBenhNhan();
        }
    }
}
